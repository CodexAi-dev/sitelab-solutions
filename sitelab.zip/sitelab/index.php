<?php
include 'get_feedbacks.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SiteLab Solutions</title>
  <link rel="stylesheet" href="about.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
/>
</head>
<body>
  <div class="whatsapp-float" id="whatsapp-btn">
    <div id="whatsapp-animation"></div>
  </div>
  <!-- Navbar -->
  <header class="navbar">
    <div class="navbar-container">
      <div class="logo">
        <img src="assets/images/logo.png" alt="logo" class="logo-img">
        <span>SiteLab Solutions</span>
      </div>
      <nav>
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><a href="#pricing">Pricing</a></li>
          <li><a href="#cart">Cart</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Sticky Panel -->
  <div class="sticky-panel">
    <a href="mailto:shanjanith9@gmail.com" class="panel-item email"><i class="fas fa-envelope"></i><span
        class="panel-text">shanjanith9@gmail.com</span></a>
    <a href="tel:+94779299274" class="panel-item phone"><i class="fas fa-phone"></i><span class="panel-text">+94 77 92
        99 274</span></a>
    <a href="https://www.linkedin.com/in/dilshandev" target="_blank" class="panel-item linkedin"><i
        class="fab fa-linkedin"></i><span class="panel-text">linkedin.com/in/dilshandev</span></a>
  </div>

  <!-- Hero Section -->
  <section class="hero" id="hero">
    <div class="hero-content">
      <h1>Build Your Dream Website</h1>
      <p>We build professional websites, sell domains & hosting, offer graphic design, and provide all the tools your
        business needs—all in one place.</p>
      <a href="#contact" class="btn">Get a Quote</a>
      <a href="#start" class="btn btn-secondary">Start Project</a>
    </div>
    <img src="assets/images/hbg.png" alt="Hero Image" class="hero-image">
  </section>

  <hr class="color-line">

<!-- Services Section --> <section class="services" id="services"> <h2>Our Services</h2> <div class="service-cards"> <!-- Web Development Card --> <div class="card"> <img src="assets/images/web-dev.png" alt="Web Development"> <h3>Web Development</h3> <p>Responsive, modern websites tailored to your business needs.</p> <div class="card-extra"> <p>We provide full-stack web development, including frontend, backend, APIs, and performance optimization. Perfect for businesses of all sizes.</p> <button class="close-card">Close</button> </div> <button class="see-more">See More</button> </div> <!-- UI/UX Design Card --> <div class="card"> <img src="assets/images/ui-ux.png" alt="UI/UX Design"> <h3>UI/UX Design</h3> <p>Intuitive and attractive designs to engage your users.</p> <div class="card-extra"> <p>We provide UI/UX solutions to make your applications intuitive and visually appealing, enhancing user engagement.</p> <button class="close-card">Close</button> </div> <button class="see-more">See More</button> </div> <!-- SEO & Marketing Card --> <div class="card"> <img src="assets/images/seo.png" alt="SEO & Marketing"> <h3>SEO & Marketing</h3> <p>Increase traffic and visibility with optimized strategies.</p> <div class="card-extra"> <p>Our SEO & marketing services help your business grow online through search engine optimization, content marketing, and social media strategies.</p> <button class="close-card">Close</button> </div> <button class="see-more">See More</button> </div> <!-- Hosting & Domain Card --> <div class="card"> <img src="assets/images/hosting.png" alt="Hosting & Domain"> <h3>Hosting & Domain</h3> <p>Affordable hosting plans and domain registration to get your business online.</p> <div class="card-extra"> <p>We provide reliable hosting services and domain registration, ensuring your website is fast, secure, and always online.</p> <button class="close-card">Close</button> </div> <button class="see-more">See More</button> </div> <!-- Graphic Design Card --> <div class="card"> <img src="assets/images/graphic.png" alt="Graphic Design"> <h3>Graphic Design</h3> <p>Creative logos, banners, and branding materials that make your brand stand out.</p> <div class="card-extra"> <p>Our graphic design services create stunning visuals including logos, branding, and promotional materials that communicate your brand identity effectively.</p> <button class="close-card">Close</button> </div> <button class="see-more">See More</button> </div> </div> </section>

  <!-- Portfolio & Feedback -->
  <section class="portfolio-stats" id="portfolio">
    <div class="portfolio-container">
      <div class="portfolio-left">
        <img src="assets/images/achiev.png" alt="Portfolio Illustration">
      </div>
      <div class="portfolio-right">
        <h2>Our Achievements</h2>
        <div class="stats">
          <div class="stat-item">
            <h3 class="number" data-target="85">0</h3>
            <p>Projects Completed</p>
          </div>
          <div class="stat-item">
            <h3 class="number" data-target="12">0</h3>
            <p>Clients</p>
          </div>
          <div class="stat-item">
            <h3 class="number" data-target="2">0</h3>
            <p>Years of Experience</p>
          </div>
        </div>

  <?php
$avgFullStars = floor($averageRating);
$avgHalfStar = ($averageRating - $avgFullStars >= 0.5) ? 1 : 0;
$avgEmptyStars = 5 - $avgFullStars - $avgHalfStar;

// Build the stars HTML
$averageStarsHtml = '';
$averageStarsHtml .= str_repeat('<i class="fas fa-star"></i>', $avgFullStars);
if ($avgHalfStar) {
    $averageStarsHtml .= '<i class="fas fa-star-half-alt"></i>';
}
$averageStarsHtml .= str_repeat('<i class="far fa-star"></i>', $avgEmptyStars);
?>
<div class="average-rating">
    <span>Average Rating:</span>
    <?php echo $averageStarsHtml; ?> (<?php echo $averageRating; ?>/5)
</div>

        <!-- Feedback Carousel Vertical -->
        <div class="feedback-carousel-vertical">
          <div class="feedback-track-vertical">
            <?php
            if (!empty($feedbacks)) {
              foreach ($feedbacks as $fb) {
                $stars = str_repeat('★', $fb['rating']) . str_repeat('☆', 5 - $fb['rating']);
                ?>
                <div class="feedback-card-vertical">
                  <div class="feedback-header">
                    <img src="<?php echo $fb['avatar']; ?>" alt="<?php echo $fb['client_name']; ?>" class="feedback-avatar">
                    <div class="feedback-info">
                      <p class="feedback-name"><?php echo $fb['client_name']; ?></p>
                      <div class="feedback-stars"><?php echo $stars; ?></div>
                    </div>
                  </div>
                  <p class="feedback-text">"<?php echo $fb['feedback_text']; ?>"</p>
                </div>
                <?php
              }
            } else {
              echo "<p>No feedbacks yet. Be the first to submit!</p>";
            }
            ?>
          </div>
        </div>

      </div>
    </div>
  </section>
<!-------- About Section -------->
<section id="about-us">
  <div class="container">
    <!-- Who We Are -->
    <div class="about-intro">
      <h2>Who We Are</h2>
      <p>We are a team of highly skilled web developers, designers, and digital strategists committed to transforming ideas into impactful digital solutions. With years of experience in creating websites, applications, and e-commerce platforms, we combine creativity, technology, and strategy to help businesses thrive online. Our approach focuses on understanding your goals, delivering user-friendly interfaces, and ensuring your digital presence stands out in a competitive market.</p>
    </div>

    <!-- About Our Company -->
    <div class="company-info">
      <h3>About Our Company</h3>
      <p>Founded with a vision to revolutionize digital experiences, our company has grown into a trusted partner for businesses of all sizes. We specialize in web development, mobile applications, UI/UX design, and digital marketing solutions. Our mission is to empower our clients by providing innovative, reliable, and scalable digital solutions tailored to their unique needs.

We believe in innovation, quality, and integrity, ensuring every project we undertake exceeds expectations. From startups to established enterprises, we collaborate closely with our clients, offering continuous support and guidance throughout the digital journey.</p>
    </div>

    <!-- Vision & Mission Cards -->
    <div class="vision-mission-cards">
      <div class="card vision-card">
        <h4>Vision</h4>
        <p>To be the most trusted web development partner globally.</p>
      </div>
      <div class="card mission-card">
        <h4>Mission</h4>
        <p>To provide innovative and effective digital solutions for businesses of all sizes.</p>
      </div>
    </div>
</section>
<!-- founder images -->
<!-- Founder / Team Section -->
<section class="founder-section">
  <div class="founder">
    <div class="founder-image-container">
      <img src="assets/images/ceo.jpg" class="founder-image" alt="Founder 1">
    </div>
    <h4 class="founder-name">Dilshan Janith</h4>
    <p class="founder-title">Founder & CEO</p>
  </div>
  <div class="founder">
    <div class="founder-image-container">
      <img src="assets/images/#.jpg" class="founder-image" alt="Founder 2">
    </div>
    <h4 class="founder-name">Kanchana Madhushan</h4>
    <p class="founder-title">Co-Founder & CTO</p>
  </div>
  <div class="founder">
    <div class="founder-image-container">
      <img src="assets/images/des2.jpg" class="founder-image" alt="Founder 3">
    </div>
    <h4 class="founder-name">Sudarshana Wickramarathne</h4>
    <p class="founder-title">Chief Designer</p>
  </div>
  <div class="founder">
    <div class="founder-image-container">
      <img src="assets/images/marh.jpg" class="founder-image" alt="Founder 4">
    </div>
    <h4 class="founder-name">Dilshan Silva</h4>
    <p class="founder-title">Marketing Head</p>
  </div>
</section>

  <!-- Forms Section -->
  <section class="forms-section">
    <div class="forms-container">
      <div class="form-left">
        <h2>Contact Us</h2>
        <form>
          <input type="text" placeholder="Name" required>
          <input type="email" placeholder="Email" required>
          <textarea placeholder="Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
      <div class="form-right">
        <h2>Submit Feedback</h2>
        <form action="submit_feedback.php" method="post" enctype="multipart/form-data">
          <input type="text" name="client_name" placeholder="Your Name" required>
          <input type="email" name="email" placeholder="Your Gmail" required pattern="[a-z0-9._%+-]+@gmail\.com$">
          <textarea name="feedback_text" placeholder="Your Feedback" required></textarea>
          <div class="rating-inline">
            <span>Rate Us</span>
            <div class="star-rating">
              <input type="radio" id="star5" name="rating" value="5" required><label for="star5"
                title="5 stars">★</label>
              <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="4 stars">★</label>
              <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="3 stars">★</label>
              <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="2 stars">★</label>
              <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="1 star">★</label>
            </div>
          </div>
          <button type="submit">Submit Feedback</button>
        </form>
      </div>
    </div>
  </section>

 <footer class="footer">
  <div class="footer-container">
    <div class="footer-about">
      <h3>Site Lab Solutions</h3>
      <p>Building modern and responsive web solutions with clean code and innovative designs.</p>
    </div>
    <div class="footer-links">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="#services">Services</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="#about">About</a></li>
      </ul>
    </div>
    <div class="footer-contact">
      <h4>Contact</h4>
      <p>Email: info@sitelab.com</p>
      <p>Phone: +94 77 92 99 274</p>
      <div class="footer-social">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
        <a href="#"><i class="fab fa-github"></i></a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2025 Site Lab Solutions. All rights reserved.</p>
  </div>
</footer>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.12.2/lottie.min.js"></script>
  <script src="script.js"></script>
</body>

</html>