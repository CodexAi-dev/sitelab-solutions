<?php
include 'Dbconfig.php';

// Fetch feedbacks including rating
$sql = "SELECT client_name, email, feedback_text, rating FROM feedbacks ORDER BY id DESC";
$result = $conn->query($sql);

$feedbacks = [];
$totalRating = 0;
$feedbackCount = 0;

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $email = strtolower(trim($row['email']));
    $hash = md5($email);
    $avatar = "https://www.gravatar.com/avatar/$hash?d=identicon&s=50";

    $feedbacks[] = [
      'client_name' => $row['client_name'],
      'feedback_text' => $row['feedback_text'],
      'avatar' => $avatar,
      'rating' => (int) $row['rating']
    ];

    $totalRating += (int) $row['rating'];
    $feedbackCount++;
  }
}

// Calculate average rating
$averageRating = $feedbackCount > 0 ? round($totalRating / $feedbackCount, 1) : 0;
?>