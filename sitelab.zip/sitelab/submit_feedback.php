<?php
include 'Dbconfig.php';

// Get POST data
$client_name = $_POST['client_name'];
$email = $_POST['email'];
$feedback_text = $_POST['feedback_text'];
$rating = $_POST['rating'];

// Sanitize inputs
$client_name = htmlspecialchars($client_name);
$email = htmlspecialchars($email);
$feedback_text = htmlspecialchars($feedback_text);
$rating = intval($rating);

// Validate rating
if ($rating < 1 || $rating > 5) {
  $rating = 0;
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO feedbacks (client_name, email, feedback_text, rating) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sssi", $client_name, $email, $feedback_text, $rating);
$stmt->execute();
$stmt->close();
$conn->close();

// Redirect back
header("Location: index.php");
exit;
?>