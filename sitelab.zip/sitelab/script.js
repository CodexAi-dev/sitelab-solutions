document.addEventListener('DOMContentLoaded', () => {
  /* -------------------- Lottie Animation -------------------- */
  let container = document.getElementById('lottie-fixed');
  if (!container) {
    container = document.createElement('div');
    container.id = 'lottie-fixed';
    container.setAttribute('aria-hidden', 'true');
    document.body.appendChild(container);
  }

  if (typeof lottie !== 'undefined') {
    lottie.loadAnimation({
      container: container,
      renderer: 'svg',
      loop: true,
      autoplay: true,
      path: 'assets/animations/hello-animation.json',
      rendererSettings: { preserveAspectRatio: 'xMidYMid meet' }
    });
  }
   // Load your WhatsApp animation JSON
    const whatsappAnim = lottie.loadAnimation({
      container: document.getElementById("whatsapp-animation"),
      renderer: "svg",
      loop: true,
      autoplay: true,
      path: "assets/animations/wappbutton.json" // <-- replace with your animation file
    });

    // On click, open WhatsApp chat (works on PC & Mobile)
    document.getElementById("whatsapp-btn").addEventListener("click", () => {
      const phone = "94779299274"; // <-- replace with your WhatsApp number
      const message = "Hello, I want more info!"; // optional pre-filled text
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank");
    });

  /* -------------------- Card Expand -------------------- */
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    const seeMore = card.querySelector('.see-more');
    const closeBtn = card.querySelector('.close-card');

    seeMore?.addEventListener('click', e => {
      e.stopPropagation();
      card.classList.add('expanded');
      document.body.classList.add('card-expanded');
    });

    closeBtn?.addEventListener('click', e => {
      e.stopPropagation();
      card.classList.remove('expanded');
      document.body.classList.remove('card-expanded');
    });

    card.addEventListener('click', e => e.stopPropagation());
  });

  document.body.addEventListener('click', () => {
    cards.forEach(card => card.classList.remove('expanded'));
    document.body.classList.remove('card-expanded');
  });

  /* -------------------- Counters -------------------- */
  const counters = document.querySelectorAll('.number');
  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-target');
      const count = +counter.innerText;
      const increment = target / 200;

      if (count < target) {
        counter.innerText = Math.ceil(count + increment);
        setTimeout(updateCount, 5);
      } else {
        counter.innerText = target;
      }
    };
    updateCount();
  });

  /* -------------------- Horizontal Feedback Carousel -------------------- */
  const feedbackTrack = document.querySelector('.feedback-track');
  const feedbackCards = document.querySelectorAll('.feedback-card');
  if (feedbackTrack && feedbackCards.length > 0) {
    let indexH = 0;
    setInterval(() => {
      feedbackCards.forEach((card, idx) => card.classList.remove('active'));
      feedbackCards[indexH].classList.add('active');
      indexH = (indexH + 1) % feedbackCards.length;
    }, 4000);
  }

  /* -------------------- Vertical Feedback Carousel -------------------- */
  const feedbackCardsVertical = document.querySelectorAll('.feedback-card-vertical');
  if (feedbackCardsVertical.length > 0) {
    let indexV = 0;

    // Initialize first card
    feedbackCardsVertical.forEach((card, i) => card.classList.remove('active'));
    feedbackCardsVertical[indexV].classList.add('active');

    setInterval(() => {
      feedbackCardsVertical[indexV].classList.remove('active');
      indexV = (indexV + 1) % feedbackCardsVertical.length;
      feedbackCardsVertical[indexV].classList.add('active');
    }, 4000);
  }
});
